from Zero_ILumi_Calculadora_Package.Calculadora.Calculadora_Completa.Calcular import Calculadora

if __name__ == '__main__':
    Calculadora()
